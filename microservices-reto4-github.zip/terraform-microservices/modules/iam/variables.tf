variable "project_name"     { type = string }
variable "environment"      { type = string }
variable "aws_account_id"   { type = string }
variable "aws_region"       { type = string }
variable "eks_cluster_name" { type = string }
